install.packages("readxl")
install.packages("ggplot2")
install.packages("carData")
install.packages("car")
install.packages("emmeans")
install.packages("lme4")
install.packages("lmerTest")
install.packages("ggsignif")
install.packages("ggthemes")
install.packages("plotrix")
install.packages("tidyverse")
install.packages("dplyr")
install.packages("broom")
install.packages("MuMIn")


library(readxl)
library(ggplot2)
library(carData)
library(car)
library(nlme)
library(emmeans)
library(lme4)
library(lmerTest)
library(ggsignif)
library(ggthemes)
library(plotrix)
library(tidyverse)
library(dplyr)
library(broom)
library(MuMIn)

#load soil sample data
setwd("C:/Users/roybe/OneDrive - UvA/Documenten/Vulnerable_Earth_project/proposal/datasets")

Soil <- read_xlsx("soil_samples.xlsx", sheet=5)

# Data inspectie
str(Soil)

### Figuren soil characteristics
Soil$Sample<-as.factor(Soil$Sample)

# ml to numeric
Soil$Rate <- as.numeric(Soil$Rate)
Soil$infil <- as.numeric(Soil$infil)

#remove S1

Soil <- Soil[Soil$Sample != "S1", ]


rm("Soil")

Soil <- Soil %>%
  mutate(
    Sample = recode(
      Sample,
      "AB1 Bottom" = "A1 Bottom",
      "A1 top"    = "A1 Top",
      "AB1 Middle"  = "A1 Middle",
      "AB2 bottom" = "A2 Bottom",
      "AB2 Middle" = "A2 Middle",
      "AB2 Top" = "A2 Top",
      "V2 low" = "V2 Bottom",
      "V2 top" = "V2 Top",
    )
  )

# Define your color palette manually
sample_colors <- c(
  "A1 Bottom" = "red",
  "A1 top" = "red",
  "A1 Middle" = "red",
  "A2 bottom" = "blue",
  "A2 Middle" = "blue",
  "A2 Top" = "blue",
  "V1.1" = "green",
  "V1.2" = "green",
  "V1.3" = "green",
  "V2 Bottom" = "darkgreen",
  "v2 Top" = "darkgreen",
  "C1" = "purple",
  "S1" = "orange"
)

# Plot with custom colors
ggplot(Soil, aes(x = Rate, y = infil, color = Sample, group = Sample)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  geom_smooth(se = FALSE, method = "lm") +
  scale_color_manual(values = sample_colors) +
  labs(
    title = "Infiltration Rate vs Water Infiltrated",
    x = "Infiltration Rate (5 min)",
    y = "Water Infiltrated (mm)",
    color = "Sample ID"
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
    legend.position = "right"
  )


# mutate dataset to distinguish vineyards from abandonened lands
Soil_type <- Soil %>%
  mutate(Land_use = if(Sample = "A1 Bottom", "AB1 top", "AB1 Middle", "AB2 bottom", "AB2 Middle", "AB2 Top" & Sample = "V1.1", "V1.2", "V1.3", "V2 low", "V2 top", "Vineyards", "Abandoned lands"))

library(dplyr)

Soil_type <- Soil %>%
  mutate(
    Land_use = case_when(
      grepl("^A", Sample) ~ "Abandoned lands",
      grepl("^V", Sample)  ~ "Vineyards",
      Sample == "C1"       ~ "Connecting area",
      Sample == "S1" ~ "Source Area",
      TRUE ~ NA_character_  # in case any other samples exist
    ))

# Simply view your dataset
View(Soil_type)
    
#t-test, verschil infiltration rates between abandoned lands and vineyards
subset_VA <- Soil_type %>%
  filter(Land_use %in% c("Vineyards", "Abandoned lands"))
t.test(Rate ~ Land_use, data = subset_VA, var.equal = FALSE)

#add dataset SOM to infiltration rate
SOM_data <- read_xlsx("SOM Labwork.xlsx", sheet=1)
colnames(SOM_data)[11] <- "SOM"
colnames(SOM_data)[1] <- "Sample"
SOM_data$Sample <- as.factor(SOM_data$Sample)

library(dplyr)
library(stringr)  # for str_to_upper()

# get percentages of SOM
SOM_data$SOM <- as.numeric(SOM_data$SOM)
SOM_data <- SOM_data %>%
  mutate(SOM = SOM * 100)

subset_SOM <- SOM_data%>%
  filter(SOM > 0)

infil_SOM<- left_join(Soil_type, SOM_data, by=c("Sample"))

# anova different groups
infil_SOM2 <- infil_SOM %>%
  filter(Land_use %in% c("Vineyards", "Abandoned lands"))
table(infil_SOM2$Land_use)
mod1 <- lm(infil ~ Land_use * SOM, data=infil_SOM2)
mod1_2 <- lm(log(infil) ~ Land_use * SOM, data=infil_SOM2)
mod2 <- lm(SOM ~ Land_use * infil, data=infil_SOM2)
mod3
anova(mod1_2)
anova(mod2)


par(mfrow = c(2,2))
plot(mod1)
plot(mod1_2)
plot(mod2)
plot(mod1_2)

ggplot(infil_SOM2, aes(x = infil, y = SOM, colour=Land_use)) +
  geom_point(alpha = 0.7) +
  geom_smooth(method = "lm", formula = y ~ x, aes(fill = Land_use), alpha = 0.2) +
  theme_minimal()+
  ylab("SOM (%)") +
  xlab("Water infiltrated (ml)")+
  guides(colour=guide_legend(title="Land use")) + guides(fill=FALSE)

ggplot(infil_SOM2, aes(x = SOM, y = infil, colour=Land_use)) +
  geom_point(alpha = 0.7) +
  geom_smooth(method = "lm", formula = y ~ x, aes(fill = Land_use), alpha = 0.2) +
  theme_minimal()+
  ylab("Water infiltrated (ml)") +
  xlab("SOM (%)")+
  guides(colour=guide_legend(title="Land use")) + guides(fill=FALSE)

ggplot(infil_SOM2, aes(x = Sample, y = infil, colour=Land_use)) +
  geom_point(alpha = 0.7) +
  geom_smooth(method = "lm", formula = y ~ x, aes(fill = Land_use), alpha = 0.2) +
  theme_minimal()+
  ylab("SOM (%)") +
  xlab("Water infiltrated (ml)")+
  guides(colour=guide_legend(title="Land use")) + guides(fill=FALSE)

#add biodiversity data
bio_data <- read_xlsx("Fieldwork_Biodiversity.xlsx", sheet=1)
colnames(bio_data)[7] <- "Species"

Soil_3<- left_join(infil_SOM, bio_data, by=c("Sample"))
soil_4 <- Soil_3 %>%
  filter(Land_use %in% c("Vineyards", "Abandoned lands"))
table(infil_SOM2$Land_use)
t.test(SOM ~ Land_use, data = soil_4, var.equal = FALSE)

mod6 <- lm(SOM ~ Land_use * Species, data=soil_4)
mod6_2 <- lm(log(SOM) ~ Land_use * Species, data=soil_4)

par(mfrow = c(2,2))
plot(mod6)
plot(mod6_2)

anova(mod3)
anova(mod3_2)

agg <- read_xlsx("Aggregate_Stability.xlsx", sheet=1)
Soil_full<- left_join(soil_4, agg, by=c("Sample"))
colnames(Soil_full)[21] <- "Agg_index"
icp <- read_xlsx("ICP_results.xlsx", sheet = 1)
soil_full2<- left_join(Soil_full, icp, by=c("Sample"))
soil_f2 <- soil_full2[-9, ]
soil_f2$Agg_index <- as.numeric(soil_f2$Agg_index)
colnames(soil_f2)[25] <- "K"


t.test(SOM ~ Land_use, data = soil_f2, var.equal = FALSE)
t.test(infil ~ Land_use, data = soil_f2, var.equal = FALSE)
t.test(Species ~ Land_use, data = soil_f2, var.equal = FALSE)
t.test(Agg_index ~ Land_use, data = soil_f2, var.equal = FALSE)
t.test(K ~ Land_use, data = soil_f2, var.equal = FALSE)

install.packages("writexl")
library(writexl)

write_xlsx(soil_f2, "Soil_V3.xlsx")
