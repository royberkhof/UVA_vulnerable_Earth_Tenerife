# 🗺️ ArcGIS Dataset README

## 📘 Basic Information
**Title: V3_proposal_GIS_analysis.gdb
**Version: 1
**Date Updated: 25-10-2025
**Author/Organization: Roy Berkhof & James Hong, University of Amsterdam
**Contact: roy.berkhof@student.uva.nl & james.hong@student.uva.nl
**License: CC BY 4.0 license 
**Keywords: Tenerife, Vilaflor, UVA

---

## 🧭 Overview
**Summary:**  
(Briefly describe what the dataset represents and why it was created.)

**Purpose:**  
(Explain the intended use and goals of the dataset.)

**Geographic Coverage:**  
Tenerife

**Temporal Coverage:**  
2005-2018 

**Scale / Resolution:**  
(e.g., "1:10,000 vector data" or "10-meter raster resolution")  

---

## 🗂️ Dataset Contents
| Layer / Feature Class | Geometry Type | Description | Coordinate System |
|------------------------|----------------|--------------|-------------------|
| roads | Polyline | Major and minor roads | NAD 1983 UTM Zone 10N |
| parcels | Polygon | Land ownership parcels | same as above |
| zoning | Polygon | Land use zoning areas | same as above |

### Attribute Descriptions
| Field Name | Description | Data Type | Example |
|-------------|--------------|-----------|----------|
| `LAND_USE` | Land use category code | Integer | 1 = Residential |
| `POP_DENSITY` | Population density per km² | Float | 1325.7 |
| `UPDATED` | Last update date | Date | 2025-09-01 |

---

## 📐 Coordinate System
**Projection:** NAD 1983 UTM Zone 10N  
**Datum:** North American Datum 1983  
**Units:** meters  
**EPSG Code:** 26910  

---

## ⚙️ Data Sources & Methodology
**Sources:**  
- [U.S. Census Bureau TIGER/Line Shapefiles](https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.html)  
- Local survey data (2022)  

**Processing Steps:**  
1. Data imported into ArcGIS Pro 3.2  
2. Topology validation and correction  
3. Attribute normalization and domain assignment  
4. Exported to File Geodatabase  

**Accuracy:**  
±10 meters positional accuracy (estimated)  
Attributes verified with 2023 reference data  

---

## ⚠️ Known Issues & Limitations
- Some attributes (e.g., zoning codes) may not reflect updates after 2024.  
- Dataset not suitable for parcel-level legal analysis.  
- No elevation or 3D features included.  

---

## 🧩 Usage Notes
- Compatible with **ArcGIS Pro 3.0+** and **ArcMap 10.8+**.  
- Symbology layer file provided: `symbology.lyrx`.  
- Best used for **regional planning**, **transportation analysis**, or **cartographic display**.  

---

## 🔗 Related Resources
- [ArcGIS Online Item Page](https://www.arcgis.com/)  
- [Metadata (ISO 19115 XML)](metadata.xml)  
- Related dataset: `Oregon_Roads_2023.gdb`  

---

## 🧾 Citation
If you use this dataset, please cite as follows:

> Author, A. (2025). *Oregon Transportation Network Dataset (Version 2.1)*.  
> Oregon Department of Transportation. https://data.odot.state.or.us

---

## 📄 Metadata
Detailed metadata is available in `metadata.xml` (ISO 19115 compliant).  

---

**Last Updated:** YYYY-MM-DD  
**Maintainer:** [Name / Organization]
